//
//  _0240111_Example_login__switch_to_tag_type_list_with_countsApp.swift
//  20240111 Example login, switch to tag type list with counts
//
//  Created by Robert A Wilkinson on 2024-01-12.
//

import SwiftUI

@main
struct _0240111_Example_login__switch_to_tag_type_list_with_countsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
